package com.example.milespergallon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView topic;
    EditText milesIN;
    EditText gallonsIN;
    EditText mpgIN;
    double miles = 1;
    double gallons = 1;
    double mpg = 1.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        topic = (TextView) findViewById(R.id.topic);
        milesIN = (EditText) findViewById(R.id.milesIN);
        gallonsIN = (EditText) findViewById(R.id.gallonsIN);
        mpgIN = (EditText) findViewById(R.id.mpgIN);



        mpgIN.setEnabled(false);

        milesIN.addTextChangedListener(milesWatcher);
        gallonsIN.addTextChangedListener(gallonsWatcher);
    }

    private TextWatcher milesWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (s.toString().length() > 0) {
                miles = Double.parseDouble(s.toString());
                showMPG();
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    private TextWatcher gallonsWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (s.toString().length() > 0) {
                gallons = Double.parseDouble(s.toString());
                showMPG();
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void showMPG(){
        if(gallons > 0)
        mpg = miles / gallons;

        mpgIN.setText(String.format("%.3f", mpg));
    }

}
